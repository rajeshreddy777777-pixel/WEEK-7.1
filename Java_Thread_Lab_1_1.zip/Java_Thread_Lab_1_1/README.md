# Java OOPS Lab 1.1 — Multithreading

## AIM
Create three concurrent threads that print `Good Morning` every 1 second, `Hello` every 2 seconds, and `Welcome` every 3 seconds, using both `Thread` and `Runnable`.

## Files
- `ThreadDemo.java` — extends the `Thread` class
- `RunnableDemo.java` — implements the `Runnable` interface

## Compile and run
Run each program separately from this folder:

```bash
javac ThreadDemo.java
java ThreadDemo
```

```bash
javac RunnableDemo.java
java RunnableDemo
```

Both programs run indefinitely. Stop them with **Ctrl+C** in the terminal. The output order can vary because the threads run concurrently.

## Algorithm
1. Define three thread tasks with different messages.
2. Print the corresponding message inside an infinite loop.
3. Pause using `Thread.sleep(1000)`, `Thread.sleep(2000)`, or `Thread.sleep(3000)`.
4. Handle `InterruptedException` by ending the thread.
5. Create all three threads and call `start()` on each.

## Result
The programs demonstrate concurrent execution using both extending `Thread` and implementing `Runnable`.
